-- MySQL dump 10.13  Distrib 5.5.39, for Win64 (x86)
--
-- Host: localhost    Database: lab_estoque
-- ------------------------------------------------------
-- Server version	5.5.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `entrada`
--

DROP TABLE IF EXISTS `entrada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrada` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data` timestamp NULL DEFAULT NULL,
  `fornecedor` varchar(45) DEFAULT NULL,
  `anotacao` text,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_entrada_usuario1_idx` (`usuario_id`),
  CONSTRAINT `fk_entrada_usuario1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrada`
--

LOCK TABLES `entrada` WRITE;
/*!40000 ALTER TABLE `entrada` DISABLE KEYS */;
INSERT INTO `entrada` VALUES (2,'2014-04-01 03:00:00','DISOMED','',NULL),(3,'2014-04-01 03:00:00','SAFRA','',NULL),(4,'2014-03-31 03:00:00','Estoque ','',NULL),(5,'2014-05-05 03:00:00','Papelaria','',NULL),(6,'2014-05-16 03:00:00','DISOMED','',NULL),(7,'2014-06-02 03:00:00','Loja Synth','',NULL),(8,'2014-07-29 03:00:00','SAFRA','',NULL),(9,'2014-07-30 03:00:00','DISOMED','',NULL),(10,'2014-08-19 03:00:00','DISOMED','',NULL),(11,'2014-09-03 03:00:00','DISOMED','',NULL),(12,'2014-09-15 03:00:00','CIAL','',NULL),(13,'2014-10-17 03:00:00','DISOMED','',NULL),(14,'2014-10-18 03:00:00','MERCADO','',NULL),(16,'2014-11-18 03:00:00','Reutilizaveis','Um dos eletrodos foi quebrado durante experimento do projeto CajuÃ­.',NULL),(17,'2014-11-25 03:00:00','Drogaria Rocha','',NULL),(18,'2014-11-27 03:00:00','Eletronica','LubrificaÃ§Ã£o dos microscopios (cremalheiras).',NULL),(19,'2014-12-11 03:00:00','Micro Optica','RecuperaÃ§Ã£o de microscopio esteroscopio trinocular com zoom danificado.',NULL),(23,'2014-12-12 03:00:00','EletrÃ´nica SÃ£o Paulo','RegulaÃ§Ã£o de luz para microscopio.',NULL),(24,'2015-03-06 03:00:00','EletrÃ´nica SÃ£o Paulo','RecuperaÃ§Ã£o de fonte de luz para microscopio queimada',NULL),(25,'2015-03-12 03:00:00','EletrÃ´nica SÃ£o Paulo','Compatibilidade com fonte de luz recuperada (regulaÃ§Ã£o da luz)',NULL),(26,'2015-03-16 03:00:00','EletrÃ´nica SÃ£o Paulo','RecuperaÃ§Ã£o de fonte de luz para microscopio queimada.',NULL),(27,'2015-03-17 03:00:00','EletrÃ´nica SÃ£o Paulo','recuperaÃ§Ã£o de fonte de luz para microscopio queimada.',NULL),(28,'2015-03-20 03:00:00','EletrÃ´nica SÃ£o Paulo','',NULL),(29,'2015-03-20 03:00:00','DISOMED','',NULL),(30,'2015-04-06 03:00:00','FASB','',NULL),(31,'2015-04-17 03:00:00','DISOMED','',NULL);
/*!40000 ALTER TABLE `entrada` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrada_de_material`
--

DROP TABLE IF EXISTS `entrada_de_material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrada_de_material` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrada_id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `lote_id` int(11) DEFAULT NULL,
  `valor` decimal(10,0) DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`entrada_id`,`material_id`),
  KEY `fk_entrada_has_material_material1_idx` (`material_id`),
  KEY `fk_entrada_has_material_entrada1_idx` (`entrada_id`),
  KEY `fk_entrada_de_material_lote1_idx` (`lote_id`),
  CONSTRAINT `fk_entrada_de_material_lote1` FOREIGN KEY (`lote_id`) REFERENCES `lote` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_entrada_has_material_entrada1` FOREIGN KEY (`entrada_id`) REFERENCES `entrada` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_entrada_has_material_material1` FOREIGN KEY (`material_id`) REFERENCES `material` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=280 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrada_de_material`
--

LOCK TABLES `entrada_de_material` WRITE;
/*!40000 ALTER TABLE `entrada_de_material` DISABLE KEYS */;
INSERT INTO `entrada_de_material` VALUES (1,2,7,NULL,0,2),(2,2,8,NULL,0,10),(3,2,9,NULL,0,2),(4,3,10,NULL,0,5),(5,3,11,NULL,0,9),(6,3,12,NULL,0,50),(34,5,38,NULL,0,4),(35,6,39,NULL,0,1),(36,7,40,NULL,0,1),(37,7,41,NULL,0,1),(38,7,42,NULL,0,1),(39,7,43,NULL,0,1),(40,8,10,NULL,0,6),(41,8,44,NULL,0,8),(42,8,45,NULL,0,4),(43,9,46,NULL,0,10),(44,9,47,NULL,0,200),(45,9,48,NULL,0,4),(46,9,49,NULL,0,3),(47,9,50,NULL,0,2),(48,10,51,NULL,0,100),(49,11,13,NULL,0,1),(50,11,34,NULL,0,15),(51,11,49,NULL,0,4),(52,11,52,NULL,0,1),(53,12,53,NULL,0,1),(54,12,54,NULL,0,1),(55,12,55,NULL,0,2),(56,12,56,NULL,0,1),(57,12,57,NULL,0,1),(58,12,58,NULL,0,1),(59,12,59,NULL,0,1),(60,12,60,NULL,0,2),(61,12,61,NULL,0,2),(62,12,62,NULL,0,6),(63,12,63,NULL,0,1),(64,12,64,NULL,0,1),(74,14,39,NULL,0,1),(75,14,74,NULL,0,1),(76,14,75,NULL,0,1),(77,14,76,NULL,0,2),(169,13,13,NULL,0,1),(170,13,48,NULL,0,5),(171,13,49,NULL,0,2),(172,13,50,NULL,0,2),(173,13,65,NULL,0,1),(174,13,67,NULL,0,2),(175,13,70,NULL,0,2),(176,13,71,NULL,0,2),(177,13,130,NULL,0,400),(178,17,131,1,0,2),(179,16,100,NULL,0,6),(180,16,101,NULL,0,1),(181,16,102,NULL,0,1),(182,16,103,NULL,0,2),(183,16,104,NULL,0,4),(184,16,105,NULL,0,1),(185,16,107,NULL,0,1),(186,16,108,NULL,0,1),(187,16,109,NULL,0,2),(188,16,110,NULL,0,1),(189,16,111,NULL,0,10),(190,16,112,NULL,0,3),(191,16,113,NULL,0,1),(192,16,114,NULL,0,1),(193,16,115,NULL,0,2),(194,16,116,NULL,0,1),(195,16,117,NULL,0,2),(196,16,118,NULL,0,1),(197,16,119,NULL,0,3),(198,16,120,NULL,0,1),(199,16,121,NULL,0,1),(200,16,122,NULL,0,2),(201,16,123,NULL,0,2),(202,16,124,NULL,0,1),(203,16,125,NULL,0,2),(204,16,77,NULL,0,1),(205,16,78,NULL,0,4),(206,16,79,NULL,0,2),(207,16,80,NULL,0,3),(208,16,81,NULL,0,5),(209,16,82,NULL,0,5),(210,16,83,NULL,0,5),(211,16,84,NULL,0,7),(212,16,85,NULL,0,9),(213,16,86,NULL,0,3),(214,16,87,NULL,0,5),(215,16,88,NULL,0,6),(216,16,90,NULL,0,6),(217,16,91,NULL,0,6),(218,16,92,NULL,0,6),(219,16,93,NULL,0,1),(220,16,94,NULL,0,1),(221,16,95,NULL,0,33),(222,16,96,NULL,0,2),(223,16,97,NULL,0,2),(224,16,98,NULL,0,4),(225,16,99,NULL,0,2),(233,26,139,NULL,0,1),(234,25,138,NULL,0,1),(235,24,135,NULL,0,1),(236,24,136,NULL,0,1),(237,24,137,NULL,0,1),(238,23,134,NULL,0,3),(239,19,133,NULL,0,1),(240,18,132,2,0,1),(241,27,138,NULL,0,1),(242,28,140,NULL,0,1),(243,29,13,NULL,0,1),(244,29,49,NULL,0,6),(245,29,52,NULL,0,1),(246,30,38,NULL,0,1),(247,31,141,3,0,20),(248,31,142,4,0,10),(249,31,143,5,0,10),(250,31,144,6,0,8),(251,31,145,7,0,2),(252,31,146,8,0,10),(253,4,13,NULL,0,6),(254,4,14,NULL,0,12),(255,4,15,NULL,0,150),(256,4,16,NULL,0,12),(257,4,17,NULL,0,1),(258,4,18,NULL,0,7),(259,4,19,NULL,0,1),(260,4,21,NULL,0,2),(261,4,22,9,0,1),(262,4,23,10,0,1),(263,4,24,NULL,0,10),(264,4,25,11,0,1),(265,4,26,12,0,1),(266,4,27,13,0,1),(267,4,28,14,0,1),(268,4,29,15,0,1),(269,4,30,16,0,1),(270,4,31,17,0,1),(271,4,32,NULL,0,2),(272,4,33,NULL,0,63),(273,4,34,NULL,0,4),(274,4,35,NULL,0,5),(275,4,36,NULL,0,1000),(276,4,37,NULL,0,100),(277,4,7,NULL,0,2),(278,4,9,NULL,0,1),(279,4,147,NULL,0,1);
/*!40000 ALTER TABLE `entrada_de_material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grupo`
--

DROP TABLE IF EXISTS `grupo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grupo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  `grupo_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_grupo_grupo1_idx` (`grupo_id`),
  CONSTRAINT `fk_grupo_grupo1` FOREIGN KEY (`grupo_id`) REFERENCES `grupo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grupo`
--

LOCK TABLES `grupo` WRITE;
/*!40000 ALTER TABLE `grupo` DISABLE KEYS */;
INSERT INTO `grupo` VALUES (1,'PeÃ§as de reposiÃ§Ã£o',NULL),(2,'',NULL);
/*!40000 ALTER TABLE `grupo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `laboratorio`
--

DROP TABLE IF EXISTS `laboratorio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laboratorio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `laboratorio`
--

LOCK TABLES `laboratorio` WRITE;
/*!40000 ALTER TABLE `laboratorio` DISABLE KEYS */;
INSERT INTO `laboratorio` VALUES (1,'lab ratos'),(2,'Quimica/Bioquimica'),(3,'Biotecnologia'),(4,'Microbiologia'),(5,'Anatomofisiologia'),(6,'Terapeutico'),(7,'Semiologia'),(8,'Comportamento Experimental'),(9,'Tecnologia de Alimentos'),(10,'Biofisica'),(11,'Mostra de Cursos'),(12,'Projeto CDL'),(13,'PÃ³s Ed. Fisica'),(14,'ManutenÃ§Ã£o'),(15,'DissecaÃ§Ã£o de cobaias'),(16,'ANATOMOFISIOLOGIA'),(17,'ANATOMOFISIOLOGIA'),(18,'ANATOMOFISIOLOGIA'),(19,'ANATOMOFISIOLOGIA'),(20,'ANATOMOFISIOLOGIA'),(21,'ANATOMOFISIOLOGIA'),(22,'ANATOMOFISIOLOGIA');
/*!40000 ALTER TABLE `laboratorio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lote`
--

DROP TABLE IF EXISTS `lote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  `validade` timestamp NULL DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lote`
--

LOCK TABLES `lote` WRITE;
/*!40000 ALTER TABLE `lote` DISABLE KEYS */;
INSERT INTO `lote` VALUES (1,'24599431','2015-06-30 03:00:00',2),(2,'1WN47835','2024-03-31 03:00:00',1),(3,'451404G','2019-03-31 03:00:00',0),(4,'5232','2018-10-30 03:00:00',0),(5,'5425','2018-12-31 03:00:00',0),(6,'1767','2017-01-31 03:00:00',0),(7,'5459','2019-01-31 03:00:00',0),(8,'5212','2018-10-30 03:00:00',0),(9,'L9732','2008-12-31 03:00:00',1),(10,'E9309','2008-05-31 03:00:00',1),(11,'A9044','2008-01-31 03:00:00',1),(12,'B9816','2009-02-28 03:00:00',1),(13,'A9758','2009-01-31 03:00:00',1),(14,'H9509','2008-08-30 03:00:00',1),(15,'I9623','2008-09-30 03:00:00',1),(16,'A9761','2009-01-31 03:00:00',1),(17,'A9775','2009-01-31 03:00:00',1);
/*!40000 ALTER TABLE `lote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material`
--

DROP TABLE IF EXISTS `material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `material` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  `descricao` varchar(45) DEFAULT NULL,
  `imagem` blob,
  `quantidade` int(11) DEFAULT NULL,
  `grupo_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_reagente_grupo_idx` (`grupo_id`),
  CONSTRAINT `fk_reagente_grupo` FOREIGN KEY (`grupo_id`) REFERENCES `grupo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material`
--

LOCK TABLES `material` WRITE;
/*!40000 ALTER TABLE `material` DISABLE KEYS */;
INSERT INTO `material` VALUES (7,'Rolo AlgodÃ£o (500g)','','http://192.168.9.242:8080/images/ampolas.jpg',3,NULL),(8,'Lamina fosca (cx)','','',3,NULL),(9,'Lamina de bisturi (cx)','','',2,NULL),(10,'Detergente neutro (500ml)','','',0,NULL),(11,'Peneirinha plastica (unid)','','',0,NULL),(12,'Colher plastica (unid)','','',0,NULL),(13,'Luvas (P) cx.','','',0,NULL),(14,'Mascara Cirurgica (cx)','','',4,NULL),(15,'Seringa 20 ml (unid)','','',150,NULL),(16,'Aguarras (500ml)','','http://localhost:8080/images/ampolas.jpg',12,NULL),(17,'Esparadrapo (rolo)','','',0,NULL),(18,'LenÃ§ol hospitalar (rolo)','','http://192.168.9.242:8080/images/ampolas.jpg',7,NULL),(19,'Travesseiro','','',1,NULL),(21,'Bolsa para Ã¡gua quente','','http://192.168.9.242:8080/images/ampolas.jpg',2,NULL),(22,'Disco de optoquina (frasco)','','',1,NULL),(23,'Disco de bacitracina (frasco)','','',1,NULL),(24,'Descarpack (20l)','','',4,NULL),(25,'Disco de amoxacilina (frasco)','','',1,NULL),(26,'Disco de ampicilina (frasco)','','',1,NULL),(27,'Disco de ciprofloxacina (frasco)','','',1,NULL),(28,'Disco de Clorafenicol (frasco)','','',1,NULL),(29,'Disco de penicilina (frasco)','','',1,NULL),(30,'Disco de cefalotina (frasco)','','',1,NULL),(31,'Disco de vancomicina (frasco)','','',1,NULL),(32,'Lamina lisa (cx)','','',0,NULL),(33,'Soro fisiolÃ³gico (500ml)','','http://192.168.9.242:8080/images/ampolas.jpg',55,NULL),(34,'Alcool 70% (1L)','','',1,NULL),(35,'Alcool 92,8% (1L)','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(36,'Seringa 3 ml (unid)','','',973,NULL),(37,'Seringa 5 ml (unid)','','',100,NULL),(38,'Marcador para quadro branco','','',0,NULL),(39,'Touca descartavel (pct)','','',0,NULL),(40,'SoluÃ§Ã£o KCL 3M','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(41,'SoluÃ§Ã£o tampÃ£o ph 4.0','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(42,'SoluÃ§Ã£o tampÃ£o ph 7.0','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(43,'SoluÃ§Ã£o tampÃ£o ph 9.0','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(44,'Papel higienico macio (rolo)','','',5,NULL),(45,'Guardanapo (pct)','','',2,NULL),(46,'Laminulas (cx)','','',5,NULL),(47,'Tubo coleta a vacuo (edta)','','',0,NULL),(48,'Gaze (pct)','','',7,NULL),(49,'Luvas (M) cx.','','',0,NULL),(50,'Fita crepe','','',4,NULL),(51,'Coletor universal (unid)','','',60,NULL),(52,'Luvas (G) cx.','','',1,NULL),(53,'Acido ascorbico-l pa (100g)','','',0,NULL),(54,'Diclorofenol-2,6 dihidratado (5g)','','',0,NULL),(55,'Hexano (1L)','','',0,NULL),(56,'Acetato de etila (1L)','','http://localhost:8080/images/ampolas.jpg',0,NULL),(57,'Fenolftaleina pa (100g)','','',0,NULL),(58,'Acido oxalico (1kg)','','',0,NULL),(59,'Hipocolrito de sodio 10-12% (1L)','','',0,NULL),(60,'Acido cloridrico (1L)','','',0,NULL),(61,'Eter etilico (1L)','','',0,NULL),(62,'Alcool etilico absoluto (1L)','','',0,NULL),(63,'Alcool metilico (1L)','','',0,NULL),(64,'Cloroformio (1L)','','',0,NULL),(65,'Luva plastica (pct)','','',0,NULL),(67,'Soro anti-D','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(70,'Soro anti-A','','',0,NULL),(71,'Soro anti-B','','',0,NULL),(73,'Tipoia ','','',0,NULL),(74,'AlgodÃ£o em bolas (pct)','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(75,'Canudos (pct)','','',0,NULL),(76,'Caneta esferografica azul','','',0,NULL),(77,'Kit Perina','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(78,'Barra Magnetica 0.7/30','','http://192.168.9.242:8080/images/ampolas.jpg',2,NULL),(79,'Transistor (BD 135)','','http://192.168.9.242:8080/images/ampolas.jpg',1,NULL),(80,'Eletrodo Ph recarregavel','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(81,'Proveta de vidro 10 ml','','',0,NULL),(82,'Proveta de vidro 50 ml','','',0,NULL),(83,'Proveta de vidro 250 ml','','',0,NULL),(84,'Becker de vidro 25 ml','','',0,NULL),(85,'Becker de vidro 50 ml','','',0,NULL),(86,'Beker de vidro 250 ml','','',0,NULL),(87,'Becker de vidro 600 ml','','',0,NULL),(88,'Becker de vidro 1000 ml','','',0,NULL),(90,'Erlenmeyer 1000 ml','','',0,NULL),(91,'Placa de Petri 100x15','','',0,NULL),(92,'Placa de Petri 60x15','','',0,NULL),(93,'Alcoometro','','',0,NULL),(94,'Camara de Neubauer','','',0,NULL),(95,'Caixa Gerbox 250 ml','','',0,NULL),(96,'Transistor (E13007A)','','',0,NULL),(97,'Capacitor elet. (4,7uF, 400v)','','',0,NULL),(98,'Interruptor Momentaneo (int.)','','',0,NULL),(99,'LED','','',0,NULL),(100,'Pistilo 100mm','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(101,'Potenciometro 10K','','http://192.168.9.242:8080/images/ampolas.jpg',0,2),(102,'Interruptor Momentaneo','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(103,'Varistor 470K','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(104,'Resitor 100R','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(105,'Porta fusivel','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(107,'Bico de Busen','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(108,'Trafo 6+6 V 300mA','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(109,'Termometro digital','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(110,'Luva emborrachada n(6)','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(111,'Lampada Halogena (6v20w)','','http://192.168.9.242:8080/images/ampolas.jpg',6,NULL),(112,'Lampada p/ Laringoscopio','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(113,'Kit pote plasutil (3.2,4.5,7.2)','','',0,NULL),(114,'Panela de pressÃ£o 7 L','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(115,'Assadeira funda inox','','',0,NULL),(116,'Jarra medidora 1 L','','',0,NULL),(117,'Bacia plastica grande','','',0,NULL),(118,'CaÃ§arola inox','','http://192.168.9.242:8080/images/ampolas.jpg',0,NULL),(119,'Tabua para churrasco','','',0,NULL),(120,'Concha de aluminio','','',0,NULL),(121,'Escumadeira de aluminio','','',0,NULL),(122,'Colher para arroz (silicone)','','',0,NULL),(123,'Espatula vazada (silicone)','','',0,NULL),(124,'Mala para pesca','','',0,NULL),(125,'Modelador de hamburguer','','',0,NULL),(130,'Lancetas (unid.)','','',106,NULL),(131,'Tira teste p/ glicemia (cx.)','','',2,NULL),(132,'WD 40 (300 ml)','','',0,NULL),(133,'Engrenagem do movimento zoom','','',0,1),(134,'Potenciometro rotativo 10K','','',0,2),(135,'Resistor 15R','','',0,1),(136,'Resistor 82K','','',0,1),(137,'Resistor 180k','','',0,1),(138,'Potenciometro 500K','','',0,2),(139,'Resistor 2,7 R','','',0,2),(140,'Capacitor elet.(25v 100uf)','','',0,2),(141,'Gelco 24','','',0,2),(142,'Sonda nasogÃ¡strica 06','','',0,2),(143,'Sonda nasogÃ¡strica 08','','',0,2),(144,'Sonda nasogÃ¡strica 10','','',0,2),(145,'Sonda nasogÃ¡strica 10','','',0,2),(146,'Sonda nasogÃ¡strica 12','','',0,2),(147,'Tipoia ','','',1,2);
/*!40000 ALTER TABLE `material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pesquisa`
--

DROP TABLE IF EXISTS `pesquisa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pesquisa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  `data_inicial` timestamp NULL DEFAULT NULL,
  `data_fianal` timestamp NULL DEFAULT NULL,
  `isEntrada` tinyint(1) DEFAULT NULL,
  `isSaida` tinyint(1) DEFAULT NULL,
  `materiais` tinytext,
  `quantidadeMaterialDe` int(11) DEFAULT NULL,
  `quantidadeMaterialAte` int(11) DEFAULT NULL,
  `lote` varchar(45) DEFAULT NULL,
  `validadade` varchar(45) DEFAULT NULL,
  `valor` varchar(45) DEFAULT NULL,
  `quantidadeEntradaDe` int(11) DEFAULT NULL,
  `quantidadeEntradaAte` int(11) DEFAULT NULL,
  `quantidadeSaidaDe` int(11) DEFAULT NULL,
  `quantidadeSaidaAte` int(11) DEFAULT NULL,
  `laboratorio` varchar(45) DEFAULT NULL,
  `solicitante` varchar(45) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pesquisa_usuario1_idx` (`usuario_id`),
  CONSTRAINT `fk_pesquisa_usuario1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pesquisa`
--

LOCK TABLES `pesquisa` WRITE;
/*!40000 ALTER TABLE `pesquisa` DISABLE KEYS */;
/*!40000 ALTER TABLE `pesquisa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saida`
--

DROP TABLE IF EXISTS `saida`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saida` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data` timestamp NULL DEFAULT NULL,
  `laboratorio_id` int(11) NOT NULL,
  `solicitante_id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `anotacao` text,
  PRIMARY KEY (`id`),
  KEY `fk_consumo_usuario1_idx` (`usuario_id`),
  KEY `fk_consumo_laboratorio1_idx` (`laboratorio_id`),
  KEY `fk_saida_solicitante1_idx` (`solicitante_id`),
  CONSTRAINT `fk_consumo_laboratorio1` FOREIGN KEY (`laboratorio_id`) REFERENCES `laboratorio` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_consumo_usuario1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_saida_solicitante1` FOREIGN KEY (`solicitante_id`) REFERENCES `solicitante` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saida`
--

LOCK TABLES `saida` WRITE;
/*!40000 ALTER TABLE `saida` DISABLE KEYS */;
INSERT INTO `saida` VALUES (1,'2014-11-11 03:00:00',2,1,NULL,''),(3,'2014-11-11 03:00:00',4,1,NULL,NULL),(4,'2014-11-12 03:00:00',5,1,NULL,NULL),(5,'2014-11-12 03:00:00',6,1,NULL,'Kit perina (substituiÃ§Ã£o de insuflador e sonda danificados no equipamento biofeedback).'),(6,'2014-11-12 03:00:00',7,1,NULL,NULL),(7,'2014-11-12 03:00:00',8,1,NULL,'Transistor bd135 (recuperaÃ§Ã£o de controle do bebedouro da caixa de skiner (10)).\r\nTrafo 6+6v 300ma (recuperaÃ§Ã£o da saida de audio da caixa de skiner (7)).'),(8,'2014-11-12 03:00:00',9,1,NULL,NULL),(9,'2014-11-12 03:00:00',10,1,NULL,NULL),(10,'2014-11-13 03:00:00',11,4,NULL,NULL),(11,'2014-11-14 03:00:00',3,1,NULL,'Potenciometro 10k (recuperaÃ§Ã£o de regulador de luz para microscopio).\r\nporta fusivel (microscopio biologico).\r\nlampadas halogenas (microscopios biologicos com lampadas queimadas).'),(12,'2014-11-20 03:00:00',8,1,NULL,NULL),(13,'2014-11-25 03:00:00',12,1,NULL,''),(14,'2014-11-25 03:00:00',13,1,NULL,''),(15,'2014-11-27 03:00:00',14,1,NULL,'LubrificaÃ§Ã£o dos microscopios (cremalheiras).'),(16,'2014-12-12 03:00:00',14,1,NULL,'RecuperaÃ§Ã£o de microscopio esterioscopio trinocular com zoom danificado.\r\nRegulador de luz para microsocopio biologico com mau contato. '),(20,'2014-12-16 03:00:00',14,1,NULL,''),(21,'2014-12-18 03:00:00',15,1,NULL,''),(22,'2015-02-19 03:00:00',6,1,NULL,''),(23,'2015-03-09 03:00:00',14,1,NULL,'recuperaÃ§Ã£o de fonte de luz queimada para microscopio.'),(24,'2015-03-11 03:00:00',2,1,NULL,''),(25,'2015-03-11 03:00:00',4,1,NULL,''),(26,'2015-03-11 03:00:00',3,1,NULL,''),(27,'2015-03-11 03:00:00',7,1,NULL,''),(28,'2015-03-12 03:00:00',14,1,NULL,'compatibilidade com fonte de luz recuperada.'),(29,'2015-03-13 03:00:00',3,5,NULL,''),(30,'2015-03-16 03:00:00',14,1,NULL,'RecuperaÃ§Ã£o de fonte de luz para microscopio queimada'),(31,'2015-03-17 03:00:00',14,1,NULL,'recuperaÃ§Ã£o de fonte de luz para microscopio queimada.'),(32,'2015-03-23 03:00:00',3,6,NULL,''),(33,'2015-03-20 03:00:00',14,1,NULL,'SubstituiÃ§Ã£o de capacitor de acoplamento em curto na caixa de skiner 7.'),(34,'2015-03-26 03:00:00',4,1,NULL,''),(35,'2015-03-27 03:00:00',18,8,NULL,'Aula pratica utilizando ossos naturais.'),(36,'2015-04-06 03:00:00',17,7,NULL,'Aula pratica com utilizaÃ§Ã£o de coraÃ§Ã£o natural de boi.'),(37,'2015-04-07 03:00:00',19,7,NULL,'Aula pratica com coraÃ§Ã£o natural de boi.'),(38,'2015-04-10 03:00:00',20,8,NULL,'Aula pratica utilizando ossos naturais.'),(39,'2015-04-17 03:00:00',21,8,NULL,'AplicaÃ§Ã£o de prova prÃ¡tica de anatomia do curso de biomedicina.'),(40,'2015-05-04 03:00:00',4,1,NULL,''),(41,'2015-04-27 03:00:00',22,1,NULL,''),(42,'2015-05-07 03:00:00',3,9,NULL,'aula prÃ¡tica'),(43,'2015-05-07 03:00:00',2,10,NULL,'aula prÃ¡tica'),(44,'2015-05-07 03:00:00',4,10,NULL,'PreparaÃ§Ã£o de reagentes e meios de cultura'),(45,'2015-05-11 03:00:00',7,1,NULL,'');
/*!40000 ALTER TABLE `saida` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saida_de_material`
--

DROP TABLE IF EXISTS `saida_de_material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saida_de_material` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `saida_id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `lote_id` int(11) DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`saida_id`,`material_id`),
  KEY `fk_saida_has_material_material1_idx` (`material_id`),
  KEY `fk_saida_has_material_saida1_idx` (`saida_id`),
  KEY `fk_saida_de_material_lote1_idx` (`lote_id`),
  CONSTRAINT `fk_saida_de_material_lote1` FOREIGN KEY (`lote_id`) REFERENCES `lote` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_saida_has_material_material1` FOREIGN KEY (`material_id`) REFERENCES `material` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_saida_has_material_saida1` FOREIGN KEY (`saida_id`) REFERENCES `saida` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=288 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saida_de_material`
--

LOCK TABLES `saida_de_material` WRITE;
/*!40000 ALTER TABLE `saida_de_material` DISABLE KEYS */;
INSERT INTO `saida_de_material` VALUES (37,3,10,NULL,3),(38,3,11,NULL,9),(39,3,12,NULL,50),(40,3,13,NULL,1),(41,3,34,NULL,1),(42,3,35,NULL,3),(43,3,38,NULL,1),(44,3,44,NULL,1),(45,3,78,NULL,1),(46,3,90,NULL,6),(47,3,91,NULL,6),(48,3,92,NULL,6),(49,3,93,NULL,1),(50,3,94,NULL,1),(51,3,96,NULL,2),(52,3,97,NULL,2),(53,3,98,NULL,4),(54,3,99,NULL,2),(55,3,100,NULL,2),(56,3,102,NULL,1),(57,3,103,NULL,2),(58,3,104,NULL,4),(67,6,14,NULL,1),(68,6,24,NULL,1),(69,6,38,NULL,1),(70,6,49,NULL,1),(71,6,109,NULL,2),(72,6,112,NULL,3),(81,8,10,NULL,3),(82,8,13,NULL,1),(83,8,14,NULL,3),(84,8,39,NULL,2),(85,8,45,NULL,2),(86,8,49,NULL,2),(87,8,52,NULL,1),(88,8,65,NULL,1),(89,8,113,NULL,1),(90,8,114,NULL,1),(91,8,115,NULL,2),(92,8,116,NULL,1),(93,8,117,NULL,2),(94,8,118,NULL,1),(95,8,119,NULL,3),(96,8,120,NULL,1),(97,8,121,NULL,1),(98,8,122,NULL,2),(99,8,123,NULL,2),(100,8,124,NULL,1),(101,8,125,NULL,2),(102,9,44,NULL,1),(121,12,49,NULL,1),(122,4,7,NULL,1),(123,4,13,NULL,1),(124,4,14,NULL,1),(125,4,17,NULL,1),(126,4,38,NULL,1),(127,4,49,NULL,1),(148,10,8,NULL,4),(149,10,24,NULL,1),(150,10,32,NULL,2),(151,10,67,NULL,2),(152,10,70,NULL,2),(153,10,71,NULL,2),(154,10,74,NULL,1),(155,10,75,NULL,1),(156,10,76,NULL,2),(157,10,130,NULL,183),(164,1,10,NULL,1),(165,1,13,NULL,3),(166,1,34,NULL,3),(167,1,35,NULL,1),(168,1,40,NULL,1),(169,1,41,NULL,1),(170,1,42,NULL,1),(171,1,43,NULL,1),(172,1,47,NULL,200),(173,1,49,NULL,1),(174,1,51,NULL,30),(175,1,53,NULL,1),(176,1,54,NULL,1),(177,1,55,NULL,2),(178,1,56,NULL,1),(179,1,57,NULL,1),(180,1,58,NULL,1),(181,1,59,NULL,1),(182,1,60,NULL,2),(183,1,61,NULL,2),(184,1,62,NULL,6),(185,1,63,NULL,1),(186,1,64,NULL,1),(187,1,78,NULL,1),(188,1,80,NULL,3),(189,1,81,NULL,5),(190,1,82,NULL,5),(191,1,83,NULL,5),(192,1,84,NULL,7),(193,1,85,NULL,9),(194,1,86,NULL,3),(195,1,87,NULL,5),(196,1,88,NULL,6),(197,1,95,NULL,33),(198,1,100,NULL,4),(199,1,107,NULL,1),(201,13,13,NULL,1),(202,13,130,NULL,52),(203,14,130,NULL,19),(209,20,48,NULL,1),(210,21,36,NULL,12),(211,21,51,NULL,10),(212,21,33,NULL,2),(213,22,34,NULL,1),(214,23,135,NULL,1),(215,23,137,NULL,1),(216,23,136,NULL,1),(217,24,24,NULL,1),(218,25,24,NULL,1),(219,26,24,NULL,1),(220,27,24,NULL,1),(221,28,138,NULL,1),(222,29,8,NULL,1),(223,29,36,NULL,15),(224,30,139,NULL,1),(225,16,133,NULL,1),(226,16,134,NULL,3),(227,15,132,2,1),(228,7,10,NULL,3),(229,7,13,NULL,1),(230,7,14,NULL,2),(231,7,34,NULL,1),(232,7,49,NULL,3),(233,7,79,NULL,1),(234,7,108,NULL,1),(235,7,110,NULL,1),(236,11,9,NULL,1),(237,11,10,NULL,1),(238,11,34,NULL,11),(239,11,35,NULL,1),(240,11,46,NULL,3),(241,11,101,NULL,1),(242,11,105,NULL,1),(243,11,111,NULL,4),(244,5,34,NULL,1),(245,5,77,NULL,1),(246,31,138,NULL,1),(256,32,8,NULL,1),(257,32,46,NULL,1),(258,32,130,NULL,40),(259,33,140,NULL,1),(260,34,38,NULL,1),(262,36,49,NULL,2),(263,35,49,NULL,1),(264,37,49,NULL,1),(265,38,49,NULL,1),(266,39,49,NULL,1),(267,40,44,NULL,1),(268,41,38,NULL,1),(269,42,8,NULL,1),(270,42,46,NULL,1),(271,43,13,NULL,1),(279,44,48,NULL,1),(280,44,14,NULL,1),(281,45,33,NULL,6),(282,45,141,3,20),(283,45,142,4,10),(284,45,143,5,10),(285,45,144,6,8),(286,45,145,7,2),(287,45,146,8,10);
/*!40000 ALTER TABLE `saida_de_material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solicitante`
--

DROP TABLE IF EXISTS `solicitante`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solicitante` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  `matricula` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitante`
--

LOCK TABLES `solicitante` WRITE;
/*!40000 ALTER TABLE `solicitante` DISABLE KEYS */;
INSERT INTO `solicitante` VALUES (1,'',''),(2,'apagar',''),(3,'teste',''),(4,'Biomedicina',''),(5,'Genildo',''),(6,'ProfÂª Isabela',''),(7,'Eduardo',''),(8,'Luana',''),(9,'Mirela',''),(10,'Priscila','');
/*!40000 ALTER TABLE `solicitante` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  `senha` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-05-21  8:42:06
